<?php
/**
 * Plugin Name: msgflash – Messaging Automation for WooCommerce
 * Plugin URI: https://msgflash.com/wordpress
 * Description: Automated customer messaging for WooCommerce. Send order confirmations, shipping notifications, and cart recovery messages via WhatsApp.
 * Version: 1.0.0
 * Author: msgflash
 * Author URI: https://msgflash.com
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: msgflash-messaging-automation-for-woocommerce
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * WC tested up to: 8.0
 *
 * @package MsgFlash_Woo
 * @version 1.0.0
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('MSG_FLASH_VERSION', '1.0.0');
define('MSG_FLASH_URL', plugin_dir_url(__FILE__));
define('MSG_FLASH_PATH', plugin_dir_path(__FILE__));
define('MSG_FLASH_TEMPLATE_DIR', MSG_FLASH_PATH . 'templates/');

/**
 * Check if WooCommerce is active
 *
 * @return bool
 */
function msgflash_is_woocommerce_active() {
    return class_exists('WooCommerce');
}

/**
 * Display admin notice if WooCommerce is missing
 */
function msgflash_woocommerce_missing_notice() {
    ?>
    <div class="notice notice-error">
        <p>
            <strong><?php esc_html_e('msgflash-messaging-automation-for-woocommerce', 'msgflash-messaging-automation-for-woocommerce'); ?></strong>: 
            <?php esc_html_e('Ce plugin nécessite WooCommerce pour fonctionner. Veuillez installer WooCommerce pour utiliser les fonctionnalités de msgflash.', 'msgflash-messaging-automation-for-woocommerce'); ?>
        </p>
    </div>
    <?php
}

/**
 * Register Action Scheduler group for async message sending
 */
function msgflash_register_action_scheduler_group() {
    if (function_exists('as_register_group')) {
        as_register_group('msgflash-messaging-automation-for-woocommerce');
    }
}
add_action('init', 'msgflash_register_action_scheduler_group');

/**
 * Initialize plugin
 */
function msgflash_init() {
    // Check WooCommerce dependency
    if (!msgflash_is_woocommerce_active()) {
        add_action('admin_notices', 'msgflash_woocommerce_missing_notice');
        return;
    }

    // Load core classes
    require_once MSG_FLASH_PATH . 'includes/class-api-client.php';
    require_once MSG_FLASH_PATH . 'includes/class-admin.php';
    require_once MSG_FLASH_PATH . 'includes/class-woo-events.php';
    require_once MSG_FLASH_PATH . 'includes/class-frontend.php';

    // Initialize components
    $api_client = new MSGFlash_API_Client();
    $admin = new MSGFlash_Admin($api_client);
    $woo_events = new MSGFlash_Woo_Events($api_client);
    $frontend = new MSGFlash_Frontend();

    // Register dashboard widget
    add_action('wp_dashboard_setup', 'msgflash_register_dashboard_widget');
}
add_action('plugins_loaded', 'msgflash_init');

/**
 * Register dashboard widget
 */
function msgflash_register_dashboard_widget() {
    wp_add_dashboard_widget(
        'msgflash_dashboard_widget',
        esc_html__('Résumé msgflash', 'msgflash-messaging-automation-for-woocommerce'),
        'msgflash_render_dashboard_widget'
    );
}

/**
 * Render dashboard widget
 */
function msgflash_render_dashboard_widget() {
    include MSG_FLASH_TEMPLATE_DIR . 'dashboard-widget.php';
}

/**
 * Cleanup on plugin deactivation
 */
function msgflash_deactivate() {
    // Clear scheduled events
    wp_clear_scheduled_hook('msgflash_check_abandoned_carts');
    
    // Clear async actions (optional, they will fail gracefully anyway)
    if (function_exists('as_unschedule_all_actions')) {
        as_unschedule_all_actions('msgflash_send_order_message', array(), 'msgflash-messaging-automation-for-woocommerce');
    }
}
register_deactivation_hook(__FILE__, 'msgflash_deactivate');
