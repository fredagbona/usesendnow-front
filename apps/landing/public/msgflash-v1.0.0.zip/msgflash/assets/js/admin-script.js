/**
 * msgflash Admin JavaScript
 * Gestion des onglets, test de connexion, sélection d'instance, messages test
 */
(function($) {
    'use strict';

    // Stockage local des instances récupérées
    var cachedInstances = [];

    $(document).ready(function() {

        // ========== NAVIGATION ONGLETS ==========
        $('.msgflash-tabs .tab-button').on('click', function(e) {
            e.preventDefault();

            var tabId = $(this).data('tab');

            $('.msgflash-tabs .tab-button').removeClass('active');
            $(this).addClass('active');

            $('.msgflash-tab-content').removeClass('active');
            $('#' + tabId).addClass('active');

            window.location.hash = 'msgflash-' + tabId;
        });

        if (window.location.hash.indexOf('msgflash-') === 0) {
            var tabName = window.location.hash.replace('msgflash-', '');
            $('.msgflash-tabs .tab-button[data-tab="' + tabName + '"]').trigger('click');
        }

        // ========== TEST DE CONNEXION ==========
        $('#msgflash-test-connection').on('click', function(e) {
            e.preventDefault();

            var $button = $(this);
            var $apiKey = $('#msgflash_api_key');
            var $instancesSection = $('#msgflash-instances-section');
            var apiKey = $apiKey.val().trim();

            if (!apiKey) {
                showConnectionStatus('error', msgflashAdmin.strings.noApiKey);
                return;
            }

            $button.prop('disabled', true).html('<span class="msgflash-spinner"></span> ' + msgflashAdmin.strings.testing);
            showConnectionStatus('loading', 'Test de connexion à l\'API msgflash...');
            $instancesSection.hide();

            $.ajax({
                url: msgflashAdmin.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'msgflash_test_connection',
                    nonce: msgflashAdmin.nonce,
                    api_key: apiKey
                },
                success: function(response) {
                    if (response.success) {
                        var data = response.data;
                        var user = data.user;
                        var instances = data.instances || [];

                        cachedInstances = instances;

                        // Message de succès en français
                        var statusHtml = '<strong>Connexion réussie !</strong> Compte : ' + escapeHtml(user.full_name) + ' (' + escapeHtml(user.email) + ')';
                        statusHtml += '<br>Plan : <strong>' + escapeHtml(user.plan_name || user.plan) + '</strong>';
                        statusHtml += '<br>Statut : <span style="color: #22C55E;">' + escapeHtml(user.plan_status) + '</span>';

                        showConnectionStatus('success', statusHtml);

                        // Gérer les instances
                        if (instances.length > 0) {
                            populateInstanceSelect(instances, data.saved_instance_id || '');
                            $instancesSection.slideDown(300);
                        } else {
                            showConnectionStatus('warning', 'Aucune instance WhatsApp disponible. Connectez une instance dans votre tableau de bord msgflash avant d\'utiliser le plugin.');
                        }
                    } else {
                        showConnectionStatus('error', '<strong>Échec de connexion :</strong> ' + escapeHtml(response.data.message || 'Erreur inconnue'));
                    }
                },
                error: function(xhr) {
                    var errorMsg = 'Impossible de joindre le serveur. Veuillez réessayer.';
                    if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                        errorMsg = xhr.responseJSON.data.message;
                    }
                    showConnectionStatus('error', '<strong>Erreur :</strong> ' + escapeHtml(errorMsg));
                },
                complete: function() {
                    $button.prop('disabled', false).html(msgflashAdmin.strings.testConnection);
                }
            });
        });

        // ========== SÉLECTION D'INSTANCE ==========
        $('#msgflash_instance_id').on('change', function() {
            var instanceId = $(this).val();

            if (!instanceId) {
                $('#msgflash-instance-status').html('<span style="color: #EF4444;">Aucune instance sélectionnée.</span>');
                return;
            }

            var instanceName = $('#msgflash_instance_id option:selected').text();
            $('#msgflash-instance-status').html('Instance sélectionnée : <strong>' + escapeHtml(instanceName) + '</strong>').css('color', '#22C55E');

            $.ajax({
                url: msgflashAdmin.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'msgflash_update_instance',
                    nonce: msgflashAdmin.nonce,
                    instance_id: instanceId
                },
                success: function(response) {
                    if (response.success) {
                        // Recharger pour refléter le nouvel état
                    }
                },
                error: function() {
                    $('#msgflash-instance-status').html('<span style="color: #EF4444;">Erreur lors de la sauvegarde de l\'instance.</span>');
                }
            });
        });

        // ========== TOGGLE AUTOMATISATIONS ==========
        $('.msgflash-automation-toggle').on('change', function() {
            var $toggle = $(this);
            var automationKey = $toggle.data('automation');
            var isEnabled = $toggle.is(':checked');

            $.ajax({
                url: msgflashAdmin.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'msgflash_toggle_automation',
                    nonce: msgflashAdmin.nonce,
                    automation_key: automationKey,
                    enabled: isEnabled ? '1' : '0'
                },
                success: function(response) {
                    if (response.success) {
                        $toggle.closest('.msgflash-toggle-item').css('border-color', '#22C55E');
                        setTimeout(function() {
                            $toggle.closest('.msgflash-toggle-item').css('border-color', '');
                        }, 1000);
                    }
                }
            });
        });

        // ========== INSERTION DE VARIABLES ==========
        $('.msgflash-variable').on('click', function() {
            var variable = $(this).text();
            var $textarea = $(this).closest('.msgflash-card').find('.msgflash-template-input');

            var textarea = $textarea[0];
            var startPos = textarea.selectionStart;
            var endPos = textarea.selectionEnd;
            var text = $textarea.val();

            $textarea.val(
                text.substring(0, startPos) + variable + text.substring(endPos)
            );

            textarea.selectionStart = textarea.selectionEnd = startPos + variable.length;
            $textarea.focus();
        });

        // ========== MESSAGE TEST ==========
        $('#msgflash-send-test-message').on('click', function(e) {
            e.preventDefault();

            var $button = $(this);
            var $phone = $('#msgflash_test_phone');
            var $message = $('#msgflash_test_message');

            var phone = $phone.val().trim();
            var message = $message.val().trim();

            // Vérifier le numéro
            if (!phone) {
                showTestStatus('error', msgflashAdmin.strings.noPhone);
                return;
            }

            // Vérifier le message
            if (!message) {
                showTestStatus('error', 'Le message ne peut pas être vide.');
                return;
            }

            // Vérifier qu'une instance est sélectionnée
            var instanceId = $('#msgflash_instance_id').val();
            if (!instanceId) {
                showTestStatus('error', msgflashAdmin.strings.noInstance);
                return;
            }

            $button.prop('disabled', true).html('<span class="msgflash-spinner"></span> ' + msgflashAdmin.strings.sending);
            showTestStatus('loading', 'Envoi du message test...');

            $.ajax({
                url: msgflashAdmin.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'msgflash_send_test_message',
                    nonce: msgflashAdmin.nonce,
                    phone: phone,
                    message: message
                },
                success: function(response) {
                    if (response.success) {
                        showTestStatus('success', response.data.message + ' (ID : ' + response.data.message_id + ')');
                    } else {
                        showTestStatus('error', response.data.message || 'Échec de l\'envoi du message');
                    }
                },
                error: function() {
                    showTestStatus('error', 'La requête a échoué. Veuillez réessayer.');
                },
                complete: function() {
                    $button.prop('disabled', false).html(msgflashAdmin.strings.sendTest);
                }
            });
        });

        // ========== SOUMISSION DU FORMULAIRE ==========
        $('#msgflash-settings-form').on('submit', function(e) {
            var $submitBtn = $(this).find('button[type="submit"]');
            $submitBtn.prop('disabled', true).html('<span class="msgflash-spinner"></span> Enregistrement...');
        });

        // ========== NOTIFICATION DE SAUVEGARDE ==========
        if (typeof msgflashAdmin !== 'undefined' && msgflashAdmin.saved) {
            showNotification('Paramètres enregistrés avec succès !', 'success');
        }

    });

    // ========== FONCTIONS UTILITAIRES ==========

    function showConnectionStatus(type, message) {
        var $status = $('#msgflash-connection-status');
        $status.removeClass('success error loading warning').addClass(type).html(message);
    }

    function showTestStatus(type, message) {
        var $status = $('#msgflash-test-status');
        $status.removeClass('success error loading warning').addClass(type).html(message);
    }

    function populateInstanceSelect(instances, savedInstanceId) {
        var $select = $('#msgflash_instance_id');
        $select.empty();
        $select.append('<option value="">-- Sélectionnez une instance --</option>');

        $.each(instances, function(index, instance) {
            var label = instance.name + ' (' + instance.waNumber + ') — ' + instance.status;
            var option = $('<option></option>')
                .attr('value', instance.id)
                .text(label);

            // Pré-sélectionner l'instance sauvegardée
            if (savedInstanceId && instance.id === savedInstanceId) {
                option.prop('selected', true);
            }

            $select.append(option);
        });

        // Mettre à jour le statut affiché
        if (savedInstanceId) {
            var $selectedOption = $select.find('option:selected');
            if ($selectedOption.val()) {
                $('#msgflash-instance-status').html('Instance sélectionnée : <strong>' + escapeHtml($selectedOption.text()) + '</strong>').css('color', '#22C55E');
            }
        }
    }

    function showNotification(message, type) {
        var $notification = $('<div class="msgflash-notice ' + type + '">' + message + '</div>');
        $('.msgflash-admin-wrap').prepend($notification);

        setTimeout(function() {
            $notification.fadeOut(300, function() {
                $(this).remove();
            });
        }, 5000);
    }

    function escapeHtml(text) {
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(text));
        return div.innerHTML;
    }

})(jQuery);
