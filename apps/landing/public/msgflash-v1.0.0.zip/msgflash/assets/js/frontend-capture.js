/**
 * msgflash Frontend Capture
 * Ultra-light vanilla JS script for checkout phone capture
 * Captures phone number on blur event for abandoned cart recovery
 */
(function() {
    'use strict';

    document.addEventListener('DOMContentLoaded', function() {

        var phoneField = document.querySelector('#billing_phone');
        var firstNameField = document.querySelector('#billing_first_name');
        var sessionId = getSessionId();

        if (!phoneField) return;

        // Save session ID
        if (typeof WooCommerceParams !== 'undefined') {
            // WooCommerce session is server-side, just track our own session
        }

        // Listen for phone field blur
        phoneField.addEventListener('blur', function() {
            var phone = this.value.trim();
            var firstName = firstNameField ? firstNameField.value.trim() : '';

            if (!phone || phone.length < 8) return;

            // Basic phone validation
            var cleaned = phone.replace(/[\s\-\(\)\.]/g, '');
            var digits = cleaned.replace(/\+/g, '');
            if (digits.length < 8) return;

            // Debounce: don't send twice for same session
            if (sessionStorage.getItem('msgflash_phone_sent')) return;

            sendPhone(phone, firstName, sessionId);
        });
    });

    function sendPhone(phone, firstName, sessionId) {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', msgflashCapture.ajaxUrl, true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

        xhr.onload = function() {
            if (xhr.status >= 200 && xhr.status < 300) {
                try {
                    var response = JSON.parse(xhr.responseText);
                    if (response.success && response.data.session_id) {
                        sessionStorage.setItem('msgflash_phone_sent', '1');
                    }
                } catch (e) {
                    // Ignore parse errors
                }
            }
        };

        xhr.onerror = function() {
            // Silently fail - don't impact UX
        };

        var data = 'action=msgflash_capture_phone' +
            '&nonce=' + encodeURIComponent(msgflashCapture.nonce) +
            '&phone=' + encodeURIComponent(phone) +
            '&first_name=' + encodeURIComponent(firstName) +
            '&session_id=' + encodeURIComponent(sessionId);

        xhr.send(data);
    }

    function getSessionId() {
        var stored = sessionStorage.getItem('msgflash_session_id');
        if (stored) return stored;

        // Generate random session ID
        var chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        var id = '';
        for (var i = 0; i < 32; i++) {
            id += chars.charAt(Math.floor(Math.random() * chars.length));
        }

        sessionStorage.setItem('msgflash_session_id', id);
        return id;
    }

})();
