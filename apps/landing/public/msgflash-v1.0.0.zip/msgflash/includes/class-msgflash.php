<?php
/**
 * MSGFlash Core Plugin Class
 *
 * Main loader for the msgflash plugin. Initializes all components.
 *
 * @package MSGFlash
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Class MSGFlash
 */
final class MSGFlash {

    /**
     * Plugin instance (singleton)
     *
     * @var MSGFlash
     */
    private static $instance = null;

    /**
     * API Client instance
     *
     * @var MSGFlash_API_Client
     */
    public $api_client;

    /**
     * Admin instance
     *
     * @var MSGFlash_Admin
     */
    public $admin;

    /**
     * WooCommerce Events instance
     *
     * @var MSGFlash_Woo_Events
     */
    public $woo_events;

    /**
     * Get singleton instance
     *
     * @return MSGFlash
     */
    public static function instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor - prevent direct instantiation
     */
    private function __construct() {
        $this->define_constants();
        $this->load_dependencies();
        $this->init_hooks();
    }

    /**
     * Define plugin constants
     */
    private function define_constants() {
        if (!defined('MSG_FLASH_VERSION')) {
            define('MSG_FLASH_VERSION', '1.0.0');
        }
        if (!defined('MSG_FLASH_URL')) {
            define('MSG_FLASH_URL', plugin_dir_url(dirname(__FILE__)));
        }
        if (!defined('MSG_FLASH_PATH')) {
            define('MSG_FLASH_PATH', plugin_dir_path(dirname(__FILE__)));
        }
        if (!defined('MSG_FLASH_API_URL')) {
            define('MSG_FLASH_API_URL', 'https://srv.msgflash.com');
        }
        if (!defined('MSG_FLASH_TEMPLATE_DIR')) {
            define('MSG_FLASH_TEMPLATE_DIR', MSG_FLASH_PATH . 'templates/');
        }
    }

    /**
     * Load required files
     */
    private function load_dependencies() {
        require_once MSG_FLASH_PATH . 'includes/class-api-client.php';
        require_once MSG_FLASH_PATH . 'includes/class-admin.php';
        require_once MSG_FLASH_PATH . 'includes/class-woo-events.php';

        // Initialize components
        $this->api_client = new MSGFlash_API_Client();
        $this->admin = new MSGFlash_Admin($this->api_client);
        
        // Only load WooCommerce events if WC is active
        if ($this->is_woocommerce_active()) {
            $this->woo_events = new MSGFlash_Woo_Events($this->api_client);
        }
    }

    /**
     * Initialize WordPress hooks
     */
    private function init_hooks() {
        add_action('plugins_loaded', array($this, 'check_dependencies'));
        add_action('wp_dashboard_setup', array($this, 'register_dashboard_widget'));
    }

    /**
     * Check plugin dependencies
     */
    public function check_dependencies() {
        if (!$this->is_woocommerce_active()) {
            add_action('admin_notices', array($this, 'woocommerce_missing_notice'));
        }
    }

    /**
     * Check if WooCommerce is active
     *
     * @return bool
     */
    public function is_woocommerce_active() {
        return class_exists('WooCommerce');
    }

    /**
     * Display admin notice if WooCommerce is missing
     */
    public function woocommerce_missing_notice() {
        ?>
        <div class="notice notice-error">
            <p>
                <strong><?php esc_html_e('msgflash-messaging-automation-for-woocommerce', 'msgflash-messaging-automation-for-woocommerce'); ?></strong>: 
                <?php esc_html_e('Ce plugin nécessite WooCommerce pour fonctionner. Veuillez installer WooCommerce pour utiliser les fonctionnalités de msgflash.', 'msgflash-messaging-automation-for-woocommerce'); ?>
            </p>
        </div>
        <?php
    }

    /**
     * Register dashboard widget
     */
    public function register_dashboard_widget() {
        wp_add_dashboard_widget(
            'msgflash_dashboard_widget',
            esc_html__('Résumé msgflash', 'msgflash-messaging-automation-for-woocommerce'),
            array($this, 'render_dashboard_widget')
        );
    }

    /**
     * Render dashboard widget
     */
    public function render_dashboard_widget() {
        include MSG_FLASH_TEMPLATE_DIR . 'dashboard-widget.php';
    }

    /**
     * Prevent cloning
     */
    private function __clone() {}

    /**
     * Prevent unserialization
     */
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }
}

/**
 * Initialize the plugin
 *
 * @return MSGFlash
 */
function msgflash_init() {
    return MSGFlash::instance();
}

// Initialize on plugins_loaded
add_action('plugins_loaded', 'msgflash_init');
