<?php
/**
 * MSGFlash WooCommerce Events
 *
 * Handles WooCommerce hooks/triggers for automated messaging
 * Uses async sending via WordPress cron to avoid blocking checkout
 *
 * @package MsgFlash_Woo
 * @version 1.0.0
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Class MSGFlash_Woo_Events
 */
class MSGFlash_Woo_Events {

    /**
     * API Client instance
     *
     * @var MSGFlash_API_Client
     */
    private $api_client;

    /**
     * Constructor
     *
     * @param MSGFlash_API_Client $api_client
     */
    public function __construct($api_client) {
        $this->api_client = $api_client;
        $this->init_hooks();
    }

    /**
     * Initialize WooCommerce hooks
     */
    private function init_hooks() {
        // New order (Customer notification) - async
        add_action('woocommerce_checkout_order_processed', array($this, 'queue_new_order_message'), 10, 3);
        
        // Order shipped/completed (Customer notification) - async
        add_action('woocommerce_order_status_completed', array($this, 'queue_order_shipped_message'), 10, 1);
        
        // Handle order status changes for shipping
        add_action('woocommerce_order_status_changed', array($this, 'on_order_status_changed'), 10, 3);
        
        // Async action handlers
        add_action('msgflash_send_order_message', array($this, 'process_order_message'), 10, 3);
        
        // Abandoned cart - schedule via WordPress cron
        add_action('init', array($this, 'schedule_abandoned_cart_check'));
        add_action('msgflash_check_abandoned_carts', array($this, 'check_abandoned_carts'));
    }

    /**
     * Queue new order message (async)
     *
     * @param int      $order_id
     * @param WC_Order $order
     * @param array    $data
     */
    public function queue_new_order_message($order_id, $order, $data) {
        if (!$this->is_automation_enabled('new_order')) {
            return;
        }

        if (!$this->can_send_messages()) {
            return;
        }

        // Schedule async action - fire immediately but in background
        as_enqueue_async_action('msgflash_send_order_message', array(
            'order_id' => $order_id,
            'template_key' => 'new_order',
            'timestamp' => time()
        ), 'msgflash-messaging-automation-for-woocommerce');
    }

    /**
     * Queue order shipped message (async)
     *
     * @param int $order_id
     */
    public function queue_order_shipped_message($order_id) {
        if (!$this->is_automation_enabled('order_shipped')) {
            return;
        }

        if (!$this->can_send_messages()) {
            return;
        }

        as_enqueue_async_action('msgflash_send_order_message', array(
            'order_id' => $order_id,
            'template_key' => 'order_shipped',
            'timestamp' => time()
        ), 'msgflash-messaging-automation-for-woocommerce');
    }

    /**
     * Handle order status change
     *
     * @param int    $order_id
     * @param string $old_status
     * @param string $new_status
     */
    public function on_order_status_changed($order_id, $old_status, $new_status) {
        // Trigger shipped notification when status changes to completed
        if ($new_status === 'completed' && $old_status !== 'completed') {
            $this->queue_order_shipped_message($order_id);
        }
    }

    /**
     * Process async order message
     *
     * @param int    $order_id
     * @param string $template_key
     * @param int    $timestamp
     */
    public function process_order_message($order_id, $template_key, $timestamp) {
        $order = wc_get_order($order_id);

        if (!$order) {
            $this->log('error', 'async_order_failed', array(
                'order_id' => $order_id,
                'reason' => 'Order not found'
            ));
            return;
        }

        $result = $this->send_order_notification($template_key, $order);

        if ($result['success']) {
            $this->log('info', 'async_order_success', array(
                'order_id' => $order_id,
                'template' => $template_key,
                'message_id' => isset($result['data']['id']) ? $result['data']['id'] : ''
            ));
        } else {
            $this->log('error', 'async_order_failed', array(
                'order_id' => $order_id,
                'template' => $template_key,
                'reason' => $result['message']
            ));
        }
    }

    /**
     * Schedule abandoned cart check
     */
    public function schedule_abandoned_cart_check() {
        if (!wp_next_scheduled('msgflash_check_abandoned_carts')) {
            wp_schedule_event(time(), 'hourly', 'msgflash_check_abandoned_carts');
        }
    }

    /**
     * Check for abandoned carts
     */
    public function check_abandoned_carts() {
        if (!$this->is_automation_enabled('abandoned_cart')) {
            return;
        }

        if (!$this->can_send_messages()) {
            return;
        }

        // Get abandoned cart delay from settings
        $delay = get_option('msgflash_abandoned_cart_delay', HOUR_IN_SECONDS);

        // Get pending/failed orders older than the delay that haven't been notified
        $args = array(
            'status' => array('pending', 'failed'),
            'date_created' => '<' . (time() - $delay),
            'limit' => 10,
            'meta_query' => array(
                array(
                    'key' => '_msgflash_abandoned_notified',
                    'compare' => 'NOT EXISTS'
                )
            )
        );

        $orders = wc_get_orders($args);

        foreach ($orders as $order) {
            $result = $this->send_order_notification('abandoned_cart', $order);

            if ($result['success']) {
                // Mark as notified
                $order->update_meta_data('_msgflash_abandoned_notified', time());
                $order->save();

                $this->log('info', 'abandoned_cart_sent', array(
                    'order_id' => $order->get_id(),
                    'message_id' => isset($result['data']['id']) ? $result['data']['id'] : ''
                ));
            } else {
                $this->log('error', 'abandoned_cart_failed', array(
                    'order_id' => $order->get_id(),
                    'reason' => $result['message']
                ));
            }
        }
    }

    /**
     * Send order notification
     *
     * @param string   $template_key
     * @param WC_Order $order
     * @return array
     */
    private function send_order_notification($template_key, $order) {
        if (!$this->api_client->has_api_key()) {
            return array('success' => false, 'message' => 'API key not configured.');
        }

        if (!$this->api_client->has_instance_id()) {
            return array('success' => false, 'message' => 'No instance selected.');
        }

        // Get template content
        $templates = get_option('msgflash_templates', array());
        $template = isset($templates[$template_key]) ? $templates[$template_key] : '';

        if (empty($template)) {
            return array('success' => false, 'message' => 'Template not configured for: ' . $template_key);
        }

        // Parse template variables
        $message = $this->parse_template($template, $order);

        // Get customer phone
        $phone = $order->get_billing_phone();

        if (empty($phone)) {
            return array('success' => false, 'message' => 'No phone number for order #' . $order->get_id());
        }

        // Validate phone
        if (!$this->api_client->is_valid_phone($phone)) {
            return array('success' => false, 'message' => 'Invalid phone number: ' . $phone);
        }

        // Send via API
        return $this->api_client->send_text_message($phone, $message);
    }

    /**
     * Parse template variables
     *
     * @param string   $template
     * @param WC_Order $order
     * @return string
     */
    private function parse_template($template, $order) {
        $site_name = get_bloginfo('name');
        $order_url = $order->get_view_order_url();

        $replacements = array(
            '{first_name}' => $order->get_billing_first_name(),
            '{last_name}' => $order->get_billing_last_name(),
            '{billing_first_name}' => $order->get_billing_first_name(),
            '{billing_last_name}' => $order->get_billing_last_name(),
            '{order_id}' => $order->get_id(),
            '{order_number}' => $order->get_order_number(),
            '{order_total}' => $order->get_formatted_order_total(),
            '{order_date}' => $order->get_date_created()->date_i18n(get_option('date_format')),
            '{order_url}' => $order_url ? $order_url : '',
            '{shipping_method}' => $this->get_shipping_method($order),
            '{site_name}' => $site_name,
            '{tracking_url}' => $this->get_tracking_url($order)
        );

        // Remove empty replacements
        $replacements = array_map(function($val) {
            return $val !== '' ? $val : 'N/A';
        }, $replacements);

        return str_replace(array_keys($replacements), array_values($replacements), $template);
    }

    /**
     * Get shipping method from order
     *
     * @param WC_Order $order
     * @return string
     */
    private function get_shipping_method($order) {
        $shipping_methods = $order->get_shipping_methods();
        if (!empty($shipping_methods)) {
            $method = reset($shipping_methods);
            return $method->get_name();
        }
        return '';
    }

    /**
     * Get tracking URL from order
     *
     * @param WC_Order $order
     * @return string
     */
    private function get_tracking_url($order) {
        // Check for common tracking URL meta keys
        $meta_keys = array('_tracking_url', 'tracking_url', '_aftership_tracking_url');
        
        foreach ($meta_keys as $key) {
            $url = $order->get_meta($key);
            if (!empty($url)) {
                return $url;
            }
        }

        return '';
    }

    /**
     * Check if automation is enabled
     *
     * @param string $key
     * @return bool
     */
    private function is_automation_enabled($key) {
        $automations = get_option('msgflash_automations', array());
        return isset($automations[$key]) && $automations[$key] == 1;
    }

    /**
     * Check if we can send messages
     * (API key configured, instance selected, WooCommerce active)
     *
     * @return bool
     */
    private function can_send_messages() {
        return $this->api_client->has_api_key() && $this->api_client->has_instance_id();
    }

    /**
     * Log an event
     *
     * @param string $level
     * @param string $event
     * @param array  $context
     */
    private function log($level, $event, $context = array()) {
        if (!function_exists('wc_get_logger')) {
            return;
        }

        $logger = wc_get_logger();
        $message = sprintf(
            '[msgflash] [%s] %s: %s',
            strtoupper($level),
            $event,
            wp_json_encode($context)
        );
        $logger->log(strtolower($level) === 'error' ? 'error' : 'info', $message, array('source' => 'msgflash'));
    }

    /**
     * Cleanup on deactivation
     */
    public static function cleanup() {
        wp_clear_scheduled_hook('msgflash_check_abandoned_carts');
    }
}
