<?php
/**
 * MSGFlash Frontend Capture & Admin Helpers
 *
 * Handles checkout phone capture, abandoned cart tracking,
 * admin notice for incomplete config, and WhatsApp phone label
 *
 * @package MsgFlash_Woo
 * @version 1.0.0
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Class MSGFlash_Frontend
 */
class MSGFlash_Frontend {

    /**
     * Table name for captured phones
     *
     * @var string
     */
    private $table_name;

    /**
     * Constructor
     */
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'msgflash_captured_phones';

        $this->init_hooks();
        $this->maybe_create_table();
    }

    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // Enqueue frontend capture script
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));

        // RGPD notice at checkout
        add_action('woocommerce_checkout_billing', array($this, 'add_rgpd_notice'), 20);

        // Customize phone field label
        add_filter('woocommerce_checkout_fields', array($this, 'customize_phone_label'));

        // AJAX handlers for live capture
        add_action('wp_ajax_msgflash_capture_phone', array($this, 'ajax_capture_phone'));
        add_action('wp_ajax_nopriv_msgflash_capture_phone', array($this, 'ajax_capture_phone'));

        // Admin notice for incomplete phone config
        add_action('admin_notices', array($this, 'show_phone_config_notice'));

        // Cron cleanup
        add_action('init', array($this, 'schedule_cleanup'));
        add_action('msgflash_cleanup_captured_phones', array($this, 'cleanup_old_phones'));

        // Track order conversion
        add_action('woocommerce_new_order', array($this, 'mark_as_converted'), 10, 1);
    }

    /**
     * Create custom table if not exists
     */
    private function maybe_create_table() {
        $version = get_option('msgflash_db_version', '0');

        if (version_compare($version, '1.0', '<')) {
            global $wpdb;
            $charset_collate = $wpdb->get_charset_collate();

            $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                phone VARCHAR(20) NOT NULL,
                first_name VARCHAR(100) DEFAULT '',
                session_id VARCHAR(191) DEFAULT '',
                captured_at DATETIME NOT NULL,
                converted_to_order_id BIGINT UNSIGNED DEFAULT NULL,
                PRIMARY KEY (id),
                KEY session_id (session_id),
                KEY phone (phone),
                KEY captured_at (captured_at)
            ) $charset_collate;";

            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            dbDelta($sql);

            update_option('msgflash_db_version', '1.0');
        }
    }

    /**
     * Enqueue frontend assets (only when needed)
     */
    public function enqueue_frontend_assets() {
        $capture_enabled = get_option('msgflash_capture_enabled', 1);

        if ($capture_enabled && function_exists('is_checkout') && is_checkout()) {
            wp_enqueue_script(
                'msgflash-capture',
                MSG_FLASH_URL . 'assets/js/frontend-capture.js',
                array(),
                MSG_FLASH_VERSION,
                true
            );

            wp_localize_script('msgflash-capture', 'msgflashCapture', array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('msgflash_capture_nonce')
            ));
        }
    }

    /**
     * Customize phone field label to mention WhatsApp
     *
     * @param array $fields
     * @return array
     */
    public function customize_phone_label($fields) {
        $fields['billing']['billing_phone']['label'] = esc_html__('Téléphone (WhatsApp de préférence)', 'msgflash-messaging-automation-for-woocommerce');
        $fields['billing']['billing_phone']['placeholder'] = 'Ex: +229 XX XX XX XX';
        return $fields;
    }

    /**
     * Show admin notice if phone field is not required in WooCommerce
     */
    public function show_phone_config_notice() {
        // Only show on msgflash settings page or general admin
        $screen = get_current_screen();
        if ($screen && strpos($screen->id, 'msgflash-messaging-automation-for-woocommerce') === false) {
            return;
        }

        // Check if WooCommerce is active
        if (!function_exists('WC') || !WC()) {
            return;
        }

        // Check if phone is required
        $fields = WC()->checkout()->get_checkout_fields('billing');
        $phone_required = isset($fields['billing_phone']['required']) && $fields['billing_phone']['required'];

        if ($phone_required) {
            return;
        }

        $settings_url = admin_url('admin.php?page=wc-settings&tab=advanced&section=checkout');
        ?>
        <div class="notice notice-warning" style="padding: 16px 20px;">
            <p style="margin: 0; display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                <span style="font-size: 18px;">⚠️</span>
                <strong style="color: #856404;">
                    <?php esc_html_e('Configuration incomplète :', 'msgflash-messaging-automation-for-woocommerce'); ?>
                </strong>
                <span style="color: #856404;">
                    <?php esc_html_e('Le champ téléphone n\'est pas obligatoire sur votre boutique. Vos clients risquent de ne pas recevoir leurs notifications WhatsApp.', 'msgflash-messaging-automation-for-woocommerce'); ?>
                </span>
                <a href="<?php echo esc_url($settings_url); ?>" class="button button-primary" style="margin-left: auto; background: #856404; border-color: #755a04; color: #fff; text-decoration: none;">
                    <?php esc_html_e('Cliquer ici pour corriger', 'msgflash-messaging-automation-for-woocommerce'); ?>
                </a>
            </p>
        </div>
        <?php
    }

    /**
     * Add RGPD notice at checkout
     */
    public function add_rgpd_notice() {
        $rgpd_text = get_option('msgflash_rgpd_text', '');

        if (empty($rgpd_text)) {
            $rgpd_text = esc_html__('En renseignant votre numéro, vous acceptez de recevoir nos notifications de commande par WhatsApp.', 'msgflash-messaging-automation-for-woocommerce');
        }

        ?>
        <script type="text/javascript">
            jQuery(function($) {
                $(document).ready(function() {
                    var rgpdHtml = '<p class="msgflash-rgpd-notice" style="font-size:12px;color:#777;margin-top:4px;line-height:1.4;"><?php echo wp_kses_post($rgpd_text); ?></p>';
                    $('#billing_phone_field').after(rgpdHtml);
                });
            });
        </script>
        <?php
    }

    /**
     * AJAX: Capture phone number live
     */
    public function ajax_capture_phone() {
        check_ajax_referer('msgflash_capture_nonce', 'nonce');

        $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        $first_name = filter_input(INPUT_POST, 'first_name', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        $session_id = filter_input(INPUT_POST, 'session_id', FILTER_SANITIZE_FULL_SPECIAL_CHARS);

        if (empty($phone)) {
            wp_send_json_error(array('message' => 'Numéro requis'));
        }

        // Normalize phone
        $phone = $this->normalize_phone($phone);

        // Check if already captured in last 48h
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}msgflash_captured_phones WHERE phone = %s AND captured_at > DATE_SUB(NOW(), INTERVAL 48 HOUR) AND converted_to_order_id IS NULL ORDER BY captured_at DESC LIMIT 1",
            $phone
        ));

        if ($existing) {
            wp_send_json_success(array('message' => 'Déjà capturé'));
        }

        // Generate session ID if not provided
        if (empty($session_id)) {
            $session_id = wp_generate_password(32, false);
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $inserted = $wpdb->insert(
            $wpdb->prefix . 'msgflash_captured_phones',
            array(
                'phone' => $phone,
                'first_name' => sanitize_text_field($first_name),
                'session_id' => $session_id,
                'captured_at' => current_time('mysql')
            ),
            array('%s', '%s', '%s', '%s')
        );

        if ($inserted) {
            wp_send_json_success(array('message' => 'Capturé', 'session_id' => $session_id));
        } else {
            wp_send_json_error(array('message' => 'Erreur de sauvegarde'));
        }
    }

    /**
     * Mark a captured phone as converted (when order is placed)
     *
     * @param int $order_id
     */
    public function mark_as_converted($order_id) {
        global $wpdb;

        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        $phone = $this->normalize_phone($order->get_billing_phone());
        $session_id = WC()->session ? WC()->session->get('msgflash_session_id', '') : '';

        if (!empty($session_id)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->update(
                $wpdb->prefix . 'msgflash_captured_phones',
                array('converted_to_order_id' => $order_id),
                array('session_id' => $session_id),
                array('%d'),
                array('%s')
            );
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->update(
            $wpdb->prefix . 'msgflash_captured_phones',
            array('converted_to_order_id' => $order_id),
            array('phone' => $phone),
            array('%d'),
            array('%s')
        );
    }

    /**
     * Schedule cleanup cron
     */
    public function schedule_cleanup() {
        if (!wp_next_scheduled('msgflash_cleanup_captured_phones')) {
            wp_schedule_event(time(), 'daily', 'msgflash_cleanup_captured_phones');
        }
    }

    /**
     * Clean up captured phones older than 48h without orders
     */
    public function cleanup_old_phones() {
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->query(
            "DELETE FROM {$wpdb->prefix}msgflash_captured_phones WHERE captured_at < DATE_SUB(NOW(), INTERVAL 48 HOUR) AND converted_to_order_id IS NULL"
        );
    }

    /**
     * Normalize phone number
     *
     * @param string $phone
     * @return string
     */
    private function normalize_phone($phone) {
        $phone = trim($phone);
        $phone = preg_replace('/[\s\-\(\)\.]/', '', $phone);

        if (strpos($phone, '+') === 0) {
            return $phone;
        }

        if (strpos($phone, '00') === 0) {
            return '+' . substr($phone, 2);
        }

        $country_code = $this->get_default_country_code();

        if (strpos($phone, '0') === 0) {
            $phone = $country_code . substr($phone, 1);
        } elseif (ctype_digit($phone) && strlen($phone) >= 8) {
            $phone = $country_code . $phone;
        }

        if (strpos($phone, '+') !== 0) {
            $phone = '+' . $phone;
        }

        return $phone;
    }

    /**
     * Get default country code based on WooCommerce store base country
     *
     * @return string Country prefix (e.g., 225)
     */
    private function get_default_country_code() {
        $base_country = get_option('woocommerce_default_country', '');

        $country_prefixes = array(
            'CI' => '225', // Côte d'Ivoire
            'FR' => '33',  // France
            'BJ' => '229', // Bénin
            'SN' => '221', // Sénégal
            'ML' => '223', // Mali
            'TG' => '228', // Togo
            'BF' => '226', // Burkina Faso
            'CM' => '237', // Cameroun
            'GA' => '241', // Gabon
            'CG' => '242', // Congo
            'CD' => '243', // RD Congo
            'MG' => '261', // Madagascar
            'MA' => '212', // Maroc
            'TN' => '216', // Tunisie
            'GH' => '233', // Ghana
            'NG' => '234', // Nigeria
        );

        if (isset($country_prefixes[$base_country])) {
            return $country_prefixes[$base_country];
        }

        return '225';
    }
}
