<?php
/**
 * MSGFlash Admin
 *
 * Manages the plugin settings page, tabs, and admin UI
 *
 * @package MsgFlash_Woo
 * @version 1.0.0
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Class MSGFlash_Admin
 */
class MSGFlash_Admin {

    /**
     * API Client instance
     *
     * @var MSGFlash_API_Client
     */
    private $api_client;

    /**
     * Constructor
     *
     * @param MSGFlash_API_Client $api_client
     */
    public function __construct($api_client) {
        $this->api_client = $api_client;
        $this->init_hooks();
    }

    /**
     * Initialize hooks
     */
    private function init_hooks() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_ajax_msgflash_test_connection', array($this, 'ajax_test_connection'));
        add_action('wp_ajax_msgflash_toggle_automation', array($this, 'ajax_toggle_automation'));
        add_action('wp_ajax_msgflash_send_test_message', array($this, 'ajax_send_test_message'));
        add_action('wp_ajax_msgflash_update_instance', array($this, 'ajax_update_instance'));

        // Hook order conversion tracking
        add_action('woocommerce_new_order', array($this, 'track_order_conversion'), 10, 1);
    }

    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            esc_html__('Réglages msgflash', 'msgflash-messaging-automation-for-woocommerce'),
            esc_html__('msgflash-messaging-automation-for-woocommerce', 'msgflash-messaging-automation-for-woocommerce'),
            'manage_options',
            'msgflash-settings',
            array($this, 'render_settings_page'),
            'data:image/svg+xml;base64,' . base64_encode($this->get_menu_icon()),
            30
        );
    }

    /**
     * Get menu icon SVG
     *
     * @return string
     */
    private function get_menu_icon() {
        return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="#FFD600" d="M11 1L3 10h6l-1 9 8-10h-6l1-8z"/></svg>';
    }

    /**
     * Enqueue admin assets
     *
     * @param string $hook Current admin page hook
     */
    public function enqueue_assets($hook) {
        // Only load on our plugin page
        if ($hook !== 'toplevel_page_msgflash-settings') {
            return;
        }

        // Enqueue styles
        wp_enqueue_style(
            'msgflash-admin-style',
            MSG_FLASH_URL . 'assets/css/admin-style.css',
            array(),
            MSG_FLASH_VERSION
        );

        // Enqueue scripts
        wp_enqueue_script(
            'msgflash-admin-script',
            MSG_FLASH_URL . 'assets/js/admin-script.js',
            array('jquery'),
            MSG_FLASH_VERSION,
            true
        );

        // Localize script
        wp_localize_script('msgflash-admin-script', 'msgflashAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('msgflash_nonce'),
            'saved' => filter_input(INPUT_GET, 'settings-updated') === 'true',
            'strings' => array(
                'testing' => esc_html__('Test en cours...', 'msgflash-messaging-automation-for-woocommerce'),
                'testConnection' => esc_html__('Tester la connexion', 'msgflash-messaging-automation-for-woocommerce'),
                'sending' => esc_html__('Envoi en cours...', 'msgflash-messaging-automation-for-woocommerce'),
                'sendTest' => esc_html__('Envoyer le message test', 'msgflash-messaging-automation-for-woocommerce'),
                'noApiKey' => esc_html__('Veuillez d\'abord entrer votre clé API.', 'msgflash-messaging-automation-for-woocommerce'),
                'noPhone' => esc_html__('Veuillez entrer un numéro de téléphone.', 'msgflash-messaging-automation-for-woocommerce'),
                'noInstance' => esc_html__('Aucune instance sélectionnée. Veuillez d\'abord sélectionner une instance.', 'msgflash-messaging-automation-for-woocommerce')
            )
        ));
    }

    /**
     * Register settings
     */
    public function register_settings() {
        // API Key
        register_setting('msgflash_settings', 'msgflash_api_key', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => ''
        ));

        // Instance ID
        register_setting('msgflash_settings', 'msgflash_instance_id', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => ''
        ));

        // Automations
        register_setting('msgflash_settings', 'msgflash_automations', array(
            'type' => 'array',
            'sanitize_callback' => array($this, 'sanitize_automations'),
            'default' => array(
                'new_order' => 0,
                'order_shipped' => 0,
                'abandoned_cart' => 0
            )
        ));

        // Templates
        register_setting('msgflash_settings', 'msgflash_templates', array(
            'type' => 'array',
            'sanitize_callback' => array($this, 'sanitize_templates'),
            'default' => array(
                'new_order' => "Hello {first_name}, your order #{order_id} has been received!",
                'order_shipped' => "Hi {first_name}, your order #{order_id} has been shipped!",
                'abandoned_cart' => "Hey {first_name}, you left items in your cart. Complete your order #{order_id} now!"
            )
        ));

        // Abandoned cart delay (in seconds, default 1 hour)
        register_setting('msgflash_settings', 'msgflash_abandoned_cart_delay', array(
            'type' => 'integer',
            'sanitize_callback' => 'absint',
            'default' => HOUR_IN_SECONDS
        ));

        // Capture & Widget settings
        register_setting('msgflash_settings', 'msgflash_capture_enabled', array(
            'type' => 'integer',
            'sanitize_callback' => 'absint',
            'default' => 1
        ));

        register_setting('msgflash_settings', 'msgflash_phone_required', array(
            'type' => 'integer',
            'sanitize_callback' => 'absint',
            'default' => 0
        ));

        register_setting('msgflash_settings', 'msgflash_rgpd_text', array(
            'type' => 'string',
            'sanitize_callback' => 'wp_kses_post',
            'default' => ''
        ));
    }

    /**
     * Sanitize automations array
     *
     * @param array $input
     * @return array
     */
    public function sanitize_automations($input) {
        $sanitized = array();
        $allowed_keys = array('new_order', 'order_shipped', 'abandoned_cart');

        foreach ($allowed_keys as $key) {
            $sanitized[$key] = isset($input[$key]) ? 1 : 0;
        }

        return $sanitized;
    }

    /**
     * Sanitize templates array
     *
     * @param array $input
     * @return array
     */
    public function sanitize_templates($input) {
        $sanitized = array();
        $allowed_keys = array('new_order', 'order_shipped', 'abandoned_cart');

        foreach ($allowed_keys as $key) {
            if (isset($input[$key])) {
                $sanitized[$key] = wp_kses_post($input[$key]);
            }
        }

        return $sanitized;
    }

    /**
     * Render settings page
     */
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $msgflash_api_key = get_option('msgflash_api_key', '');
        $msgflash_instance_id = get_option('msgflash_instance_id', '');
        $msgflash_automations = get_option('msgflash_automations', array());
        $msgflash_templates = get_option('msgflash_templates', array());
        $msgflash_abandoned_cart_delay = get_option('msgflash_abandoned_cart_delay', HOUR_IN_SECONDS);

        // Capture & Widget options
        $msgflash_capture_enabled = get_option('msgflash_capture_enabled', 1);
        $msgflash_phone_required = get_option('msgflash_phone_required', 0);
        $msgflash_rgpd_text = get_option('msgflash_rgpd_text', '');

        include MSG_FLASH_TEMPLATE_DIR . 'settings-page.php';
    }

    /**
     * AJAX: Test API connection
     */
    public function ajax_test_connection() {
        check_ajax_referer('msgflash_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Non autorisé'));
        }

        $api_key = filter_input(INPUT_POST, 'api_key', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        $result = $this->api_client->test_connection($api_key);

        if ($result['success']) {
            // Ajouter l'instance ID sauvegardée pour la pré-sélection
            $result['saved_instance_id'] = get_option('msgflash_instance_id', '');
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }

    /**
     * AJAX: Toggle automation
     */
    public function ajax_toggle_automation() {
        check_ajax_referer('msgflash_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Non autorisé'));
        }

        $automation_key = filter_input(INPUT_POST, 'automation_key', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        $enabled = (bool) filter_input(INPUT_POST, 'enabled', FILTER_VALIDATE_INT);

        if (empty($automation_key)) {
            wp_send_json_error(array('message' => 'Clé d\'automatisation invalide'));
        }

        $automations = get_option('msgflash_automations', array());

        $allowed_keys = array('new_order', 'order_shipped', 'abandoned_cart');
        if (!in_array($automation_key, $allowed_keys)) {
            wp_send_json_error(array('message' => 'Clé d\'automatisation invalide'));
        }

        $automations[$automation_key] = $enabled ? 1 : 0;
        update_option('msgflash_automations', $automations);

        wp_send_json_success(array('message' => 'Automatisation mise à jour'));
    }

    /**
     * AJAX: Send test message
     */
    public function ajax_send_test_message() {
        check_ajax_referer('msgflash_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Non autorisé'));
        }

        $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        $message = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_FULL_SPECIAL_CHARS);

        if (empty($phone)) {
            wp_send_json_error(array('message' => 'Le numéro de téléphone est requis'));
        }

        if (empty($message)) {
            wp_send_json_error(array('message' => 'Le message est requis'));
        }

        if (!$this->api_client->has_api_key()) {
            wp_send_json_error(array('message' => 'Clé API non configurée'));
        }

        if (!$this->api_client->has_instance_id()) {
            wp_send_json_error(array('message' => 'Aucune instance sélectionnée. Veuillez d\'abord sélectionner une instance dans les paramètres.'));
        }

        if (!$this->api_client->is_valid_phone($phone)) {
            wp_send_json_error(array('message' => 'Format de numéro de téléphone invalide'));
        }

        $result = $this->api_client->send_text_message($phone, $message);

        if ($result['success']) {
            wp_send_json_success(array(
                'message' => 'Message test envoyé avec succès !',
                'message_id' => isset($result['data']['id']) ? $result['data']['id'] : ''
            ));
        } else {
            wp_send_json_error(array('message' => $result['message']));
        }
    }

    /**
     * AJAX: Update instance
     */
    public function ajax_update_instance() {
        check_ajax_referer('msgflash_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Non autorisé'));
        }

        $instance_id = filter_input(INPUT_POST, 'instance_id', FILTER_SANITIZE_FULL_SPECIAL_CHARS);

        if (empty($instance_id)) {
            wp_send_json_error(array('message' => 'L\'ID de l\'instance est requis'));
        }

        $this->api_client->update_instance_id($instance_id);
        update_option('msgflash_instance_id', $instance_id);

        wp_send_json_success(array('message' => 'Instance mise à jour'));
    }

    /**
     * Track order conversion for captured phone numbers
     *
     * @param int $order_id
     */
    public function track_order_conversion($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        $phone = $order->get_billing_phone();
        if (empty($phone)) {
            return;
        }

        $phone = preg_replace('/[\s\-\(\)\.]/', '', trim($phone));

        global $wpdb;
        $table_name = $wpdb->prefix . 'msgflash_captured_phones';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $table_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name));
        if (!$table_exists) {
            return;
        }

        $session_id = WC()->session ? WC()->session->get('msgflash_session_id', '') : '';

        if (!empty($session_id)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->update(
                $table_name,
                array('converted_to_order_id' => $order_id),
                array('session_id' => $session_id),
                array('%d'),
                array('%s')
            );
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->update(
            $table_name,
            array('converted_to_order_id' => $order_id),
            array('phone' => $phone),
            array('%d'),
            array('%s')
        );
    }
}
