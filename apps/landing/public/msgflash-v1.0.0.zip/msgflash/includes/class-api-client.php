<?php
/**
 * MSGFlash API Client
 *
 * HTTP client for communicating with the MsgFlash API
 * Base URL: https://srv.msgflash.com/api/v1
 * Auth: x-api-key header
 *
 * @package MsgFlash_Woo
 * @version 1.0.0
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Class MSGFlash_API_Client
 */
class MSGFlash_API_Client {

    /**
     * API Base URL
     *
     * @var string
     */
    private $api_url;

    /**
     * API Key
     *
     * @var string
     */
    private $api_key;

    /**
     * Selected Instance ID
     *
     * @var string
     */
    private $instance_id;

    /**
     * Last response
     *
     * @var array
     */
    private $last_response;

    /**
     * Last HTTP status code
     *
     * @var int
     */
    private $last_status_code;

    /**
     * Log directory
     *
     * @var string
     */
    private $log_dir;

    /**
     * Constructor
     */
    public function __construct() {
        $this->api_url = 'https://srv.msgflash.com/api/v1';
        $this->api_key = $this->get_api_key();
        $this->instance_id = $this->get_instance_id();
        $this->log_dir = $this->get_log_directory();
    }

    /**
     * Get stored API key from options
     *
     * @return string
     */
    public function get_api_key() {
        return get_option('msgflash_api_key', '');
    }

    /**
     * Update stored API key
     *
     * @param string $key
     * @return bool
     */
    public function update_api_key($key) {
        $this->api_key = sanitize_text_field($key);
        return update_option('msgflash_api_key', $this->api_key);
    }

    /**
     * Get stored instance ID from options
     *
     * @return string
     */
    public function get_instance_id() {
        return get_option('msgflash_instance_id', '');
    }

    /**
     * Update stored instance ID
     *
     * @param string $instance_id
     * @return bool
     */
    public function update_instance_id($instance_id) {
        $this->instance_id = sanitize_text_field($instance_id);
        return update_option('msgflash_instance_id', $this->instance_id);
    }

    /**
     * Check if API key is configured
     *
     * @return bool
     */
    public function has_api_key() {
        return !empty($this->api_key);
    }

    /**
     * Check if instance ID is configured
     *
     * @return bool
     */
    public function has_instance_id() {
        return !empty($this->instance_id);
    }

    /**
     * Test API connection and fetch account info
     *
     * @param string|null $api_key Optional key to test
     * @return array Response with connection status, user info, and instances
     */
    public function test_connection($api_key = null) {
        $key = $api_key ? sanitize_text_field($api_key) : $this->api_key;

        if (empty($key)) {
            return array(
                'success' => false,
                'message' => 'No API key provided.',
                'error_code' => 'MISSING_API_KEY'
            );
        }

        // Step 1: Validate API key with GET /me
        $me_response = $this->request('GET', '/me', array(), $key);

        if (!$me_response['success']) {
            return $this->format_connection_error($me_response);
        }

        $user_data = $me_response['data'];
        $user = isset($user_data['user']) ? $user_data['user'] : array();
        $subscription = isset($user_data['subscription']) ? $user_data['subscription'] : array();
        $capabilities = isset($user_data['capabilities']) ? $user_data['capabilities'] : array();

        // Step 2: Fetch instances
        $instances_response = $this->request('GET', '/instances', array(), $key);
        $instances = array();

        if ($instances_response['success'] && isset($instances_response['data']) && is_array($instances_response['data'])) {
            $instances = $instances_response['data'];
        }

        return array(
            'success' => true,
            'message' => 'Connection successful',
            'user' => array(
                'id' => isset($user['id']) ? $user['id'] : '',
                'full_name' => isset($user['fullName']) ? $user['fullName'] : 'Unknown',
                'email' => isset($user['email']) ? $user['email'] : '',
                'plan' => isset($user['plan']) ? $user['plan'] : '',
                'plan_name' => isset($subscription['planName']) ? $subscription['planName'] : '',
                'plan_status' => isset($subscription['status']) ? $subscription['status'] : '',
                'capabilities' => $capabilities
            ),
            'instances' => $instances,
            'instance_count' => count($instances)
        );
    }

    /**
     * Get available instances
     *
     * @return array
     */
    public function get_instances() {
        if (!$this->has_api_key()) {
            return array('success' => false, 'message' => 'API key not configured.');
        }

        $response = $this->request('GET', '/instances');
        return $response;
    }

    /**
     * Send a text message
     *
     * @param string $to          Destination phone number
     * @param string $message     Message body
     * @param string|null $instance_id Optional instance override
     * @return array
     */
    public function send_text_message($to, $message, $instance_id = null) {
        return $this->send_message(array(
            'instanceId' => $instance_id ? $instance_id : $this->instance_id,
            'to' => $this->normalize_phone($to),
            'type' => 'text',
            'text' => $message
        ));
    }

    /**
     * Send a media message
     *
     * @param string $to          Destination phone number
     * @param string $media_type  One of: image, video, audio, document, voice_note
     * @param string $media_url   Public URL of the media
     * @param string $caption     Optional caption
     * @param string|null $instance_id Optional instance override
     * @return array
     */
    public function send_media_message($to, $media_type, $media_url, $caption = '', $instance_id = null) {
        $payload = array(
            'instanceId' => $instance_id ? $instance_id : $this->instance_id,
            'to' => $this->normalize_phone($to),
            'type' => $media_type,
            'mediaUrl' => $media_url
        );

        if (!empty($caption)) {
            $payload['text'] = $caption;
        }

        return $this->send_message($payload);
    }

    /**
     * Send a message using a template
     *
     * @param string $to           Destination phone number
     * @param string $template_id  Template UUID
     * @param array  $variables    Template variables
     * @param string|null $instance_id Optional instance override
     * @return array
     */
    public function send_template_message($to, $template_id, $variables = array(), $instance_id = null) {
        return $this->send_message(array(
            'instanceId' => $instance_id ? $instance_id : $this->instance_id,
            'to' => $this->normalize_phone($to),
            'templateId' => $template_id,
            'variables' => $variables
        ));
    }

    /**
     * Send a message (generic method)
     *
     * @param array $payload Message payload
     * @return array
     */
    public function send_message($payload) {
        if (!$this->has_api_key()) {
            $this->log('error', 'send_message', array('error' => 'API key not configured'));
            return array('success' => false, 'message' => 'API key not configured.', 'error_code' => 'MISSING_API_KEY');
        }

        if (!$this->has_instance_id() && !isset($payload['instanceId'])) {
            $this->log('error', 'send_message', array('error' => 'No instance selected'));
            return array('success' => false, 'message' => 'No WhatsApp instance selected. Please configure an instance in settings.', 'error_code' => 'MISSING_INSTANCE');
        }

        // Normalize phone number
        if (isset($payload['to'])) {
            $payload['to'] = $this->normalize_phone($payload['to']);
        }

        $response = $this->request('POST', '/messages/send', $payload);

        if ($response['success']) {
            $this->log('info', 'message_sent', array(
                'to' => isset($payload['to']) ? $payload['to'] : '',
                'type' => isset($payload['type']) ? $payload['type'] : 'text',
                'message_id' => isset($response['data']['id']) ? $response['data']['id'] : ''
            ));
        } else {
            $this->log('error', 'send_failed', array(
                'to' => isset($payload['to']) ? $payload['to'] : '',
                'error' => $response['message'],
                'error_code' => isset($response['error_code']) ? $response['error_code'] : '',
                'status_code' => $this->last_status_code
            ));
        }

        return $response;
    }

    /**
     * Get templates
     *
     * @return array
     */
    public function get_templates() {
        if (!$this->has_api_key()) {
            return array('success' => false, 'message' => 'API key not configured.');
        }

        return $this->request('GET', '/templates');
    }

    /**
     * Normalize phone number to international format
     *
     * @param string $phone
     * @return string
     */
    public function normalize_phone($phone) {
        $phone = trim($phone);

        // Remove spaces, dashes, parentheses, dots
        $phone = preg_replace('/[\s\-\(\)\.]/', '', $phone);

        // If already starts with +, return as-is
        if (strpos($phone, '+') === 0) {
            return $phone;
        }

        // If starts with 00, replace with +
        if (strpos($phone, '00') === 0) {
            return '+' . substr($phone, 2);
        }

        // If starts with 0, we need to add country code
        // Default to Côte d'Ivoire (+225) if no country code detectable
        if (strpos($phone, '0') === 0) {
            // Check if it looks like a CI number (07, 05, 01, etc.)
            $second_digit = isset($phone[1]) ? $phone[1] : '';
            if (in_array($second_digit, array('0', '1', '4', '5', '6', '7'))) {
                return '+225' . $phone;
            }
            // Generic fallback - prepend +225
            return '+225' . $phone;
        }

        // If it's just digits without leading 0, assume it needs country code
        if (ctype_digit($phone)) {
            return '+225' . $phone;
        }

        // Return as-is if we can't parse it
        return $phone;
    }

    /**
     * Validate if a phone number is usable
     *
     * @param string $phone
     * @return bool
     */
    public function is_valid_phone($phone) {
        $normalized = $this->normalize_phone($phone);

        // Must start with + and have at least 8 digits after
        if (strpos($normalized, '+') !== 0) {
            return false;
        }

        $digits = preg_replace('/[^\d]/', '', $normalized);
        return strlen($digits) >= 8;
    }

    /**
     * Make HTTP request to API
     *
     * @param string $method   HTTP method
     * @param string $endpoint API endpoint (without /api/v1 prefix)
     * @param array  $body     Request body
     * @param string|null $api_key Optional API key
     * @return array
     */
    private function request($method, $endpoint, $body = array(), $api_key = null) {
        $key = $api_key ? $api_key : $this->api_key;
        $url = trailingslashit($this->api_url) . ltrim($endpoint, '/');

        $args = array(
            'method' => strtoupper($method),
            'timeout' => 15,
            'headers' => array(
                'Content-Type' => 'application/json',
                'x-api-key' => $key,
                'X-Plugin-Version' => defined('MSG_FLASH_VERSION') ? MSG_FLASH_VERSION : '1.0.0'
            ),
            'sslverify' => true
        );

        if (!empty($body)) {
            $args['body'] = wp_json_encode($body);
        }

        $this->log('debug', 'api_request', array(
            'method' => $method,
            'endpoint' => $endpoint,
            'url' => $url
        ));

        $response = wp_remote_request($url, $args);
        $this->last_response = $response;

        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            $this->log('error', 'api_request_failed', array(
                'endpoint' => $endpoint,
                'wp_error' => $error_message
            ));

            return array(
                'success' => false,
                'message' => 'Connection error: ' . $error_message,
                'error_code' => 'CONNECTION_ERROR'
            );
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $this->last_status_code = $response_code;
        $response_body = wp_remote_retrieve_body($response);
        $data = json_decode($response_body, true);

        // Success response
        if ($response_code >= 200 && $response_code < 300) {
            return array(
                'success' => true,
                'data' => isset($data['data']) ? $data['data'] : array(),
                'status_code' => $response_code
            );
        }

        // Error response
        $error_data = isset($data['error']) ? $data['error'] : array();
        $error_code = isset($error_data['code']) ? $error_data['code'] : 'UNKNOWN_ERROR';
        $error_message = isset($error_data['message']) ? $error_data['message'] : 'API request failed with status ' . $response_code;

        $this->log('error', 'api_error', array(
            'endpoint' => $endpoint,
            'status_code' => $response_code,
            'error_code' => $error_code,
            'message' => $error_message
        ));

        return array(
            'success' => false,
            'message' => $error_message,
            'error_code' => $error_code,
            'status_code' => $response_code,
            'meta' => isset($error_data['meta']) ? $error_data['meta'] : array()
        );
    }

    /**
     * Format connection error for UX
     *
     * @param array $response
     * @return array
     */
    private function format_connection_error($response) {
        $error_code = isset($response['error_code']) ? $response['error_code'] : '';
        $status_code = isset($response['status_code']) ? $response['status_code'] : 0;

        // Map API error codes to user-friendly messages
        $messages = array(
            'UNAUTHORIZED' => 'Invalid or revoked API key. Please check your key and try again.',
            'API_RATE_LIMIT_EXCEEDED' => 'Your monthly API quota has been reached. Please upgrade your plan.',
            'MISSING_API_KEY' => 'No API key provided.',
            'CONNECTION_ERROR' => 'Unable to connect to the MsgFlash API. Please check your internet connection.'
        );

        $message = isset($messages[$error_code]) ? $messages[$error_code] : $response['message'];

        return array(
            'success' => false,
            'message' => $message,
            'error_code' => $error_code,
            'status_code' => $status_code
        );
    }

    /**
     * Get log directory
     *
     * @return string
     */
    private function get_log_directory() {
        $upload_dir = wp_upload_dir();
        $log_dir = trailingslashit($upload_dir['basedir']) . 'msgflash-logs';

        // Create directory if it doesn't exist
        if (!file_exists($log_dir)) {
            wp_mkdir_p($log_dir);
            // Add .htaccess to prevent direct access
            $htaccess = $log_dir . '/.htaccess';
            if (!file_exists($htaccess)) {
                file_put_contents($htaccess, "deny from all\n");
            }
            // Add index.php to prevent directory listing
            $index = $log_dir . '/index.php';
            if (!file_exists($index)) {
                file_put_contents($index, '<?php // Silence is golden');
            }
        }

        return $log_dir;
    }

    /**
     * Log an event
     *
     * @param string $level   Log level: debug, info, warning, error
     * @param string $event   Event name
     * @param array  $context Additional context
     */
    private function log($level, $event, $context = array()) {
        // Only log if WP_DEBUG is enabled or for errors
        if (!defined('WP_DEBUG') || !WP_DEBUG) {
            if ($level !== 'error' && $level !== 'warning') {
                return;
            }
        }

        $log_entry = array(
            'timestamp' => current_time('mysql'),
            'level' => $level,
            'event' => $event,
            'context' => $context
        );

        $log_file = $this->log_dir . '/msgflash-' . gmdate('Y-m-d') . '.log';
        $log_line = '[' . $log_entry['timestamp'] . '] [' . strtoupper($level) . '] ' . $event . ': ' . wp_json_encode($context) . PHP_EOL;

        // Rotate logs older than 30 days
        $this->rotate_logs();

        file_put_contents($log_file, $log_line, FILE_APPEND | LOCK_EX);
    }

    /**
     * Rotate old log files (delete files older than 30 days)
     */
    private function rotate_logs() {
        if (!is_dir($this->log_dir)) {
            return;
        }

        $files = glob($this->log_dir . '/msgflash-*.log');
        $cutoff = strtotime('-30 days');

        foreach ($files as $file) {
            if (filemtime($file) < $cutoff) {
                wp_delete_file($file);
            }
        }
    }

    /**
     * Get last response
     *
     * @return array
     */
    public function get_last_response() {
        return $this->last_response;
    }

    /**
     * Get last status code
     *
     * @return int
     */
    public function get_last_status_code() {
        return $this->last_status_code;
    }
}
