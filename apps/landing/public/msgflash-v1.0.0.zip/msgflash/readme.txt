=== msgflash – Messaging Automation for WooCommerce ===
Contributors: msgflash
Donate link: https://msgflash.com
Tags: woocommerce, messaging, recovery, automation, notifications
Requires at least: 5.8
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Send automated WhatsApp messages to your WooCommerce customers: order confirmations, shipping notifications, and abandoned cart recovery.

== Description ==

**msgflash** connects your WooCommerce store to WhatsApp, enabling automated, real-time customer messaging without manual effort.

Whether you run a boutique or a high-volume store, msgflash keeps your customers informed and engaged through the channel they use every day.

= Key Features =

* **Order Confirmations** - Automatically send a WhatsApp message when a customer places an order.
* **Shipping Notifications** - Notify customers the moment their order status changes to completed/shipped.
* **Abandoned Cart Recovery** - Send reminders to customers who left items in their cart without completing their purchase.
* **Customizable Templates** - Personalize every message with variables like `{first_name}`, `{order_id}`, `{order_total}`, and more.
* **Async Processing** - Messages are sent in the background so your checkout page never slows down.
* **Phone Number Normalization** - Automatically formats phone numbers to international standards.
* **Multi-Instance Support** - Choose which WhatsApp instance to use from your MsgFlash account.

= Use Cases (2026 Patterns) =

1. **Récupération de Paniers (Cart Recovery)** - Reduce abandoned carts by automatically reaching out to customers who didn't complete checkout. Set a configurable delay (30 min to 24 hours).
2. **Notifications Transactionnelles (Transactional Notifications)** - Keep customers informed at every step: order received, order shipped, with tracking URLs.
3. **Suivi de Colis (Package Tracking)** - Include shipping method and tracking links directly in WhatsApp messages.

= How It Works =

1. Create an account on [msgflash.com](https://msgflash.com) and connect a WhatsApp instance.
2. Install the plugin and paste your API key.
3. Select your default WhatsApp instance.
4. Enable the automations you want and customize your message templates.
5. That's it — msgflash handles the rest automatically.

= Requirements =

* WordPress 5.8 or higher
* PHP 7.4 or higher
* WooCommerce 5.0 or higher
* An active MsgFlash account with at least one connected WhatsApp instance

= Important Notes =

* The plugin requires a valid MsgFlash API key (`msgf_live_...`).
* You must have at least one connected WhatsApp instance in your MsgFlash account.
* Phone numbers should be valid and in international format for reliable delivery.

= Privacy & GDPR =

This plugin sends WhatsApp messages using customer data already stored in WooCommerce (phone number, name, order details). No additional personal data is collected or transmitted to third-party services beyond the MsgFlash API required for message delivery.

== Installation ==

1. **Upload the Plugin:**
   * Download the plugin `.zip` file.
   * In your WordPress admin, go to **Plugins > Add New > Upload Plugin**.
   * Upload the `.zip` file and click **Install Now**.
2. **Activate the Plugin:**
   * Click **Activate Plugin** after installation.
3. **Generate Your API Key:**
   * Log in to your [MsgFlash dashboard](https://msgflash.com).
   * Navigate to **Settings > API Keys** and generate a new key (`msgf_live_...`).
   * Make sure you have at least one WhatsApp instance connected.
4. **Configure the Plugin:**
   * In WordPress admin, click the **msgflash** menu item.
   * Paste your API key and click **Test Connection**.
   * Select your default WhatsApp instance from the dropdown.
   * Enable the automations you want (New Order, Order Shipped, Abandoned Cart).
   * Customize your message templates with variables like `{first_name}`, `{order_id}`, etc.
5. **Save Settings and Test:**
   * Click **Save Settings**.
   * Use the **Send Test Message** feature to verify your configuration.

== Frequently Asked Questions ==

= Do I need a MsgFlash account? =
Yes. The plugin connects to your MsgFlash account via API. You can sign up at [msgflash.com](https://msgflash.com).

= What happens if a customer doesn't have a phone number? =
The plugin skips the message for orders without a valid phone number. The error is logged for your review.

= Will the plugin slow down my checkout? =
No. All message sending is done asynchronously in the background using Action Scheduler. Your checkout experience remains fast.

= Can I customize the messages? =
Yes. Each automation has a customizable template with variables: `{first_name}`, `{order_id}`, `{order_total}`, `{order_url}`, `{shipping_method}`, `{tracking_url}`, and more.

= How does abandoned cart recovery work? =
The plugin runs an hourly cron check. Orders in "pending" or "failed" status older than your configured delay (default: 1 hour) that haven't been notified will trigger a reminder message.

= Can I use my own WhatsApp number? =
The plugin uses WhatsApp instances configured in your MsgFlash account. You can manage instances from the MsgFlash dashboard.

== Screenshots ==

1. msgflash settings page with connection test and instance selection.
2. Automations tab with toggle switches for order notifications.
3. Templates editor with variable insertion.
4. Dashboard widget showing connection status and active automations.

== Changelog ==

= 1.0.0 =
* Initial release.
* API connection test with instance selection.
* New order confirmation via WhatsApp.
* Order shipped/completed notification.
* Abandoned cart recovery with configurable delay.
* Customizable message templates with variables.
* Asynchronous message processing via Action Scheduler.
* Phone number normalization.
* Local logging system.

== Upgrade Notice ==

= 1.0.0 =
Initial release of msgflash for WooCommerce.
