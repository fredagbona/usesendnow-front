<?php
/**
 * MSGFlash Dashboard Widget Template
 *
 * Displays a summary on the WordPress admin dashboard
 *
 * @package MsgFlash_Woo
 * @version 1.0.0
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

$msgflash_api_key = get_option('msgflash_api_key', '');
$msgflash_automations = get_option('msgflash_automations', array());
$msgflash_active_automations = array_filter($msgflash_automations);
?>

<div class="msgflash-dashboard-widget">
    <div class="widget-header">
        <img src="<?php echo esc_url(MSG_FLASH_URL . 'assets/img/logo-plugin.svg'); ?>" alt="msgflash">
        <h3><?php esc_html_e('msgflash-messaging-automation-for-woocommerce', 'msgflash-messaging-automation-for-woocommerce'); ?></h3>
    </div>
    
    <div class="widget-content">
        <?php if (empty($msgflash_api_key)) : ?>
            <p style="color: #A1A1AA; margin: 0 0 16px 0;">
                <?php esc_html_e('Connectez votre compte msgflash pour commencer.', 'msgflash-messaging-automation-for-woocommerce'); ?>
            </p>
            <a href="<?php echo esc_url(admin_url('admin.php?page=msgflash-settings')); ?>" class="msgflash-button-primary" style="text-decoration: none; display: inline-block;">
                <?php esc_html_e('Configurer msgflash', 'msgflash-messaging-automation-for-woocommerce'); ?>
            </a>
        <?php else : ?>
            <div class="msgflash-stats">
                <div class="msgflash-stat">
                    <div class="value">
                        <?php echo count($msgflash_active_automations); ?>
                    </div>
                    <div class="label">
                        <?php esc_html_e('Automatisations actives', 'msgflash-messaging-automation-for-woocommerce'); ?>
                    </div>
                </div>
                
                <div class="msgflash-stat">
                    <div class="value" style="color: #22C55E;">
                        <?php esc_html_e('✓', 'msgflash-messaging-automation-for-woocommerce'); ?>
                    </div>
                    <div class="label">
                        <?php esc_html_e('API connectée', 'msgflash-messaging-automation-for-woocommerce'); ?>
                    </div>
                </div>
            </div>
            
            <a href="<?php echo esc_url(admin_url('admin.php?page=msgflash-settings')); ?>" style="display: block; margin-top: 16px; color: #FFD600; text-decoration: none; font-size: 13px;">
                <?php esc_html_e('Gérer les paramètres →', 'msgflash-messaging-automation-for-woocommerce'); ?>
            </a>
        <?php endif; ?>
    </div>
</div>
