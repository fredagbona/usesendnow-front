<?php
/**
 * MSGFlash Settings Page Template
 *
 * @package MsgFlash_Woo
 * @version 1.0.0
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>

<div class="msgflash-admin-wrap">
    <!-- Header -->
    <div class="msgflash-header">
        <div class="logo">
            <img src="<?php echo esc_url(MSG_FLASH_URL . 'assets/img/logo-plugin.svg'); ?>" alt="logo msgflash">
            <div>
                <h1>
                    <?php esc_html_e('msgflash-messaging-automation-for-woocommerce', 'msgflash-messaging-automation-for-woocommerce'); ?>
                    <span class="version">v<?php echo esc_html(MSG_FLASH_VERSION); ?></span>
                </h1>
            </div>
        </div>
    </div>

    <!-- Tabs Navigation -->
    <div class="msgflash-tabs">
        <button class="tab-button active" data-tab="connection">
            <?php esc_html_e('Connexion', 'msgflash-messaging-automation-for-woocommerce'); ?>
        </button>
        <button class="tab-button" data-tab="automations">
            <?php esc_html_e('Automatisations', 'msgflash-messaging-automation-for-woocommerce'); ?>
        </button>
        <button class="tab-button" data-tab="templates">
            <?php esc_html_e('Modèles', 'msgflash-messaging-automation-for-woocommerce'); ?>
        </button>
        <button class="tab-button" data-tab="capture">
            <?php esc_html_e('Capture & Widget', 'msgflash-messaging-automation-for-woocommerce'); ?>
        </button>
    </div>

    <!-- Tab Content: Connection -->
    <div id="connection" class="msgflash-tab-content active">
        <form method="post" action="options.php" id="msgflash-settings-form">
            <?php settings_fields('msgflash_settings'); ?>
            
            <!-- API Key Card -->
            <div class="msgflash-card">
                <h2><?php esc_html_e('Connexion API', 'msgflash-messaging-automation-for-woocommerce'); ?></h2>
                <p><?php esc_html_e('Entrez votre clé API msgflash pour vous connecter à votre compte. Vous pouvez trouver votre clé API dans votre tableau de bord msgflash.', 'msgflash-messaging-automation-for-woocommerce'); ?></p>
                
                <label class="msgflash-label" for="msgflash_api_key">
                    <?php esc_html_e('Clé API', 'msgflash-messaging-automation-for-woocommerce'); ?> <span class="required">*</span>
                </label>
                <input 
                    type="password" 
                    id="msgflash_api_key" 
                    name="msgflash_api_key" 
                    class="msgflash-input" 
                    value="<?php echo esc_attr($msgflash_api_key); ?>" 
                    placeholder="msgf_live_..."
                >
                
                <div style="margin-top: 16px; display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
                    <button type="button" id="msgflash-test-connection" class="msgflash-button-primary">
                        <?php esc_html_e('Tester la connexion', 'msgflash-messaging-automation-for-woocommerce'); ?>
                    </button>
                    <button type="submit" class="msgflash-button-secondary">
                        <?php esc_html_e('Enregistrer', 'msgflash-messaging-automation-for-woocommerce'); ?>
                    </button>
                </div>
                
                <div id="msgflash-connection-status" class="msgflash-connection-status"></div>
            </div>

            <!-- Instance Selection Card (shown after successful connection) -->
            <div class="msgflash-card" id="msgflash-instances-section" style="display: <?php echo !empty($msgflash_instance_id) ? 'block' : 'none'; ?>;">
                <h2><?php esc_html_e('Instance WhatsApp', 'msgflash-messaging-automation-for-woocommerce'); ?></h2>
                <p><?php esc_html_e("Sélectionnez l'instance WhatsApp à utiliser pour l'envoi des messages. Vous devez avoir au moins une instance connectée dans votre compte msgflash.", 'msgflash-messaging-automation-for-woocommerce'); ?></p>
                
                <label class="msgflash-label" for="msgflash_instance_id">
                    <?php esc_html_e('Instance par défaut', 'msgflash-messaging-automation-for-woocommerce'); ?> <span class="required">*</span>
                </label>
                <select id="msgflash_instance_id" name="msgflash_instance_id" class="msgflash-input">
                    <option value=""><?php esc_html_e('-- Sélectionnez une instance --', 'msgflash-messaging-automation-for-woocommerce'); ?></option>
                    <?php if (!empty($msgflash_instance_id)) : ?>
                        <option value="<?php echo esc_attr($msgflash_instance_id); ?>" selected><?php echo esc_html($msgflash_instance_id); ?></option>
                    <?php endif; ?>
                </select>
                
                <div id="msgflash-instance-status" style="margin-top: 12px; font-size: 13px; color: #A1A1AA;">
                    <?php if (!empty($msgflash_instance_id)) : ?>
                        <?php esc_html_e('Instance configurée. Les messages seront envoyés via cette instance.', 'msgflash-messaging-automation-for-woocommerce'); ?>
                    <?php else : ?>
                        <span style="color: #EF4444;"><?php esc_html_e("Aucune instance sélectionnée. Testez d'abord votre connexion pour charger les instances disponibles.", 'msgflash-messaging-automation-for-woocommerce'); ?></span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Test Message Card -->
            <div class="msgflash-card">
                <h2><?php esc_html_e('Envoyer un message test', 'msgflash-messaging-automation-for-woocommerce'); ?></h2>
                <p><?php esc_html_e("Envoyez un message WhatsApp test pour vérifier votre configuration. Cela nécessite une clé API valide et une instance sélectionnée.", 'msgflash-messaging-automation-for-woocommerce'); ?></p>
                
                <label class="msgflash-label" for="msgflash_test_phone">
                    <?php esc_html_e('Numéro de téléphone', 'msgflash-messaging-automation-for-woocommerce'); ?>
                </label>
                <input 
                    type="text" 
                    id="msgflash_test_phone" 
                    class="msgflash-input" 
                    placeholder="+2250715516311"
                >
                
                <label class="msgflash-label" for="msgflash_test_message" style="margin-top: 16px;">
                    <?php esc_html_e('Message', 'msgflash-messaging-automation-for-woocommerce'); ?>
                </label>
                <textarea 
                    id="msgflash_test_message" 
                    class="msgflash-textarea" 
                    rows="3"
                ><?php echo esc_textarea('Bonjour, ceci est un message test de msgflash !'); ?></textarea>
                
                <div style="margin-top: 16px;">
                    <button type="button" id="msgflash-send-test-message" class="msgflash-button-primary">
                        <?php esc_html_e('Envoyer le message test', 'msgflash-messaging-automation-for-woocommerce'); ?>
                    </button>
                </div>
                
                <div id="msgflash-test-status" class="msgflash-connection-status"></div>
            </div>
        </form>
    </div>

    <!-- Tab Content: Automations -->
    <div id="automations" class="msgflash-tab-content">
        <form method="post" action="options.php">
            <?php settings_fields('msgflash_settings'); ?>
            
            <div class="msgflash-card">
                <h2><?php esc_html_e('Notifications automatisées', 'msgflash-messaging-automation-for-woocommerce'); ?></h2>
                <p><?php esc_html_e('Activez ou désactivez la messagerie automatique pour les événements WooCommerce. Lorsqu\'elles sont activées, les clients recevront des messages WhatsApp selon l\'activité de la boutique.', 'msgflash-messaging-automation-for-woocommerce'); ?></p>
                
                <div class="msgflash-toggle-list">
                    <!-- New Order -->
                    <div class="msgflash-toggle-item">
                        <div class="toggle-info">
                            <h4><?php esc_html_e('Nouvelle commande', 'msgflash-messaging-automation-for-woocommerce'); ?></h4>
                            <p><?php esc_html_e('Envoyer un message de confirmation quand un client passe une nouvelle commande.', 'msgflash-messaging-automation-for-woocommerce'); ?></p>
                        </div>
                        <label class="msgflash-switch">
                            <input 
                                type="checkbox" 
                                class="msgflash-automation-toggle" 
                                data-automation="new_order"
                                name="msgflash_automations[new_order]" 
                                value="1" 
                                <?php checked(isset($msgflash_automations['new_order']) && $msgflash_automations['new_order']); ?>
                            >
                            <span class="slider"></span>
                        </label>
                    </div>

                    <!-- Order Shipped -->
                    <div class="msgflash-toggle-item">
                        <div class="toggle-info">
                            <h4><?php esc_html_e('Commande expédiée', 'msgflash-messaging-automation-for-woocommerce'); ?></h4>
                            <p><?php esc_html_e('Notifier les clients quand le statut de leur commande passe à expédiée/terminée.', 'msgflash-messaging-automation-for-woocommerce'); ?></p>
                        </div>
                        <label class="msgflash-switch">
                            <input 
                                type="checkbox" 
                                class="msgflash-automation-toggle" 
                                data-automation="order_shipped"
                                name="msgflash_automations[order_shipped]" 
                                value="1" 
                                <?php checked(isset($msgflash_automations['order_shipped']) && $msgflash_automations['order_shipped']); ?>
                            >
                            <span class="slider"></span>
                        </label>
                    </div>

                    <!-- Abandoned Cart -->
                    <div class="msgflash-toggle-item">
                        <div class="toggle-info">
                            <h4><?php esc_html_e('Panier abandonné', 'msgflash-messaging-automation-for-woocommerce'); ?></h4>
                            <p><?php esc_html_e('Envoyer un rappel quand un client laisse des articles dans son panier sans finaliser l\'achat.', 'msgflash-messaging-automation-for-woocommerce'); ?></p>
                        </div>
                        <label class="msgflash-switch">
                            <input 
                                type="checkbox" 
                                class="msgflash-automation-toggle" 
                                data-automation="abandoned_cart"
                                name="msgflash_automations[abandoned_cart]" 
                                value="1" 
                                <?php checked(isset($msgflash_automations['abandoned_cart']) && $msgflash_automations['abandoned_cart']); ?>
                            >
                            <span class="slider"></span>
                        </label>
                    </div>
                </div>
                
                <div style="margin-top: 24px;">
                    <button type="submit" class="msgflash-button-primary">
                        <?php esc_html_e('Enregistrer les automatisations', 'msgflash-messaging-automation-for-woocommerce'); ?>
                    </button>
                </div>
            </div>

            <!-- Abandoned Cart Settings -->
            <div class="msgflash-card">
                <h3><?php esc_html_e('Paramètres du panier abandonné', 'msgflash-messaging-automation-for-woocommerce'); ?></h3>
                
                <label class="msgflash-label" for="msgflash_abandoned_cart_delay">
                    <?php esc_html_e('Délai avant l\'envoi du rappel', 'msgflash-messaging-automation-for-woocommerce'); ?>
                </label>
                <select id="msgflash_abandoned_cart_delay" name="msgflash_abandoned_cart_delay" class="msgflash-input" style="max-width: 300px;">
                    <option value="1800" <?php selected($msgflash_abandoned_cart_delay, 1800); ?>><?php esc_html_e('30 minutes', 'msgflash-messaging-automation-for-woocommerce'); ?></option>
                    <option value="3600" <?php selected($msgflash_abandoned_cart_delay, 3600); ?>><?php esc_html_e('1 heure', 'msgflash-messaging-automation-for-woocommerce'); ?></option>
                    <option value="7200" <?php selected($msgflash_abandoned_cart_delay, 7200); ?>><?php esc_html_e('2 heures', 'msgflash-messaging-automation-for-woocommerce'); ?></option>
                    <option value="14400" <?php selected($msgflash_abandoned_cart_delay, 14400); ?>><?php esc_html_e('4 heures', 'msgflash-messaging-automation-for-woocommerce'); ?></option>
                    <option value="28800" <?php selected($msgflash_abandoned_cart_delay, 28800); ?>><?php esc_html_e('8 heures', 'msgflash-messaging-automation-for-woocommerce'); ?></option>
                    <option value="43200" <?php selected($msgflash_abandoned_cart_delay, 43200); ?>><?php esc_html_e('12 heures', 'msgflash-messaging-automation-for-woocommerce'); ?></option>
                    <option value="86400" <?php selected($msgflash_abandoned_cart_delay, 86400); ?>><?php esc_html_e('24 heures', 'msgflash-messaging-automation-for-woocommerce'); ?></option>
                </select>
            </div>
        </form>
    </div>

    <!-- Tab Content: Templates -->
    <div id="templates" class="msgflash-tab-content">
        <form method="post" action="options.php">
            <?php settings_fields('msgflash_settings'); ?>
            
            <!-- New Order Template -->
            <div class="msgflash-card">
                <h3><?php esc_html_e('Message nouvelle commande', 'msgflash-messaging-automation-for-woocommerce'); ?></h3>
                <p><?php esc_html_e('Personnalisez le message envoyé lorsqu\'une nouvelle commande est passée.', 'msgflash-messaging-automation-for-woocommerce'); ?></p>
                
                <textarea 
                    class="msgflash-textarea msgflash-template-input" 
                    name="msgflash_templates[new_order]"
                    rows="4"
                ><?php echo esc_textarea(isset($msgflash_templates['new_order']) ? $msgflash_templates['new_order'] : ''); ?></textarea>
                
                <div class="msgflash-variables">
                    <span class="msgflash-variable">{first_name}</span>
                    <span class="msgflash-variable">{last_name}</span>
                    <span class="msgflash-variable">{order_id}</span>
                    <span class="msgflash-variable">{order_total}</span>
                    <span class="msgflash-variable">{order_date}</span>
                    <span class="msgflash-variable">{order_url}</span>
                    <span class="msgflash-variable">{site_name}</span>
                </div>
            </div>

            <!-- Order Shipped Template -->
            <div class="msgflash-card">
                <h3><?php esc_html_e('Message commande expédiée', 'msgflash-messaging-automation-for-woocommerce'); ?></h3>
                <p><?php esc_html_e('Personnalisez le message envoyé lorsqu\'une commande est expédiée.', 'msgflash-messaging-automation-for-woocommerce'); ?></p>
                
                <textarea 
                    class="msgflash-textarea msgflash-template-input" 
                    name="msgflash_templates[order_shipped]"
                    rows="4"
                ><?php echo esc_textarea(isset($msgflash_templates['order_shipped']) ? $msgflash_templates['order_shipped'] : ''); ?></textarea>
                
                <div class="msgflash-variables">
                    <span class="msgflash-variable">{first_name}</span>
                    <span class="msgflash-variable">{order_id}</span>
                    <span class="msgflash-variable">{order_total}</span>
                    <span class="msgflash-variable">{shipping_method}</span>
                    <span class="msgflash-variable">{tracking_url}</span>
                </div>
            </div>

            <!-- Abandoned Cart Template -->
            <div class="msgflash-card">
                <h3><?php esc_html_e('Message panier abandonné', 'msgflash-messaging-automation-for-woocommerce'); ?></h3>
                <p><?php esc_html_e('Personnalisez le message envoyé lorsqu\'un panier est abandonné.', 'msgflash-messaging-automation-for-woocommerce'); ?></p>
                
                <textarea 
                    class="msgflash-textarea msgflash-template-input" 
                    name="msgflash_templates[abandoned_cart]"
                    rows="4"
                ><?php echo esc_textarea(isset($msgflash_templates['abandoned_cart']) ? $msgflash_templates['abandoned_cart'] : ''); ?></textarea>
                
                <div class="msgflash-variables">
                    <span class="msgflash-variable">{first_name}</span>
                    <span class="msgflash-variable">{order_id}</span>
                    <span class="msgflash-variable">{order_total}</span>
                    <span class="msgflash-variable">{site_name}</span>
                </div>
            </div>
            
            <div style="margin-top: 24px;">
                <button type="submit" class="msgflash-button-primary">
                    <?php esc_html_e('Enregistrer les modèles', 'msgflash-messaging-automation-for-woocommerce'); ?>
                </button>
            </div>
        </form>
    </div>

    <!-- Tab Content: Capture & Widget -->
    <div id="capture" class="msgflash-tab-content">
        <form method="post" action="options.php">
            <?php settings_fields('msgflash_settings'); ?>

            <!-- Section : Capture Checkout -->
            <div class="msgflash-card">
                <h2><?php esc_html_e('Capture de données (Checkout)', 'msgflash-messaging-automation-for-woocommerce'); ?></h2>
                <p><?php esc_html_e('Capturez les numéros de téléphone des clients en temps réel pendant le processus de paiement, même s\'ils ne finalisent pas leur commande.', 'msgflash-messaging-automation-for-woocommerce'); ?></p>

                <div class="msgflash-toggle-list">
                    <!-- Live Capture -->
                    <div class="msgflash-toggle-item">
                        <div class="toggle-info">
                            <h4><?php esc_html_e('Capture en temps réel', 'msgflash-messaging-automation-for-woocommerce'); ?></h4>
                            <p><?php esc_html_e('Capturer le numéro de téléphone dès que le client le renseigne au checkout (pour relance panier abandonné).', 'msgflash-messaging-automation-for-woocommerce'); ?></p>
                        </div>
                        <label class="msgflash-switch">
                            <input
                                type="checkbox"
                                name="msgflash_capture_enabled"
                                value="1"
                                <?php checked($msgflash_capture_enabled); ?>
                            >
                            <span class="slider"></span>
                        </label>
                    </div>
                </div>

                <!-- RGPD Text -->
                <div style="margin-top: 24px;">
                    <label class="msgflash-label" for="msgflash_rgpd_text">
                        <?php esc_html_e('Mention légale (sous le champ téléphone)', 'msgflash-messaging-automation-for-woocommerce'); ?>
                    </label>
                    <textarea
                        id="msgflash_rgpd_text"
                        name="msgflash_rgpd_text"
                        class="msgflash-textarea"
                        rows="2"
                    ><?php echo esc_textarea($msgflash_rgpd_text); ?></textarea>
                    <p style="font-size: 12px; color: #71717A; margin-top: 6px;">
                        <?php esc_html_e('Laissez vide pour utiliser le texte par défaut : "En renseignant votre numéro, vous acceptez de recevoir nos notifications de commande par WhatsApp."', 'msgflash-messaging-automation-for-woocommerce'); ?>
                    </p>
                </div>
            </div>

            <div style="margin-top: 24px;">
                <button type="submit" class="msgflash-button-primary">
                    <?php esc_html_e('Enregistrer', 'msgflash-messaging-automation-for-woocommerce'); ?>
                </button>
            </div>
        </form>
    </div>
</div>
